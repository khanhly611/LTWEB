﻿using Microsoft.AspNetCore.Mvc;

namespace StudentManagement.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC";
            return View();
        }

        public IActionResult About()
        {
            ViewBag.Message = "Tên sinh viên: Đỗ Khánh Ly";
            return View();
        }

        public IActionResult Contact()
        {
            ViewBag.Message = "Email: bcs240027@st.cmcu.edu.vn";
            return View();
        }
    }
}