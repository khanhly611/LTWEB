﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.Models;

namespace StudentManagement.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Info()
        {
            // ViewBag
            ViewBag.Name = "Nguyễn Văn A";

            // ViewData
            ViewData["Age"] = 20;

            // Model
            Student student = new Student();
            student.Major = "CNTT";

            return View(student);
        }
    }
}