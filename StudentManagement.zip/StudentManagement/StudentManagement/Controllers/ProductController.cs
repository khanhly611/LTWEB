﻿using Microsoft.AspNetCore.Mvc;

namespace StudentManagement.Controllers
{
    public class ProductController : Controller
    {
        // /Product/Detail/5
        public IActionResult Detail(int? id)
        {
            if (id == null)
            {
                ViewBag.Message = "Lỗi: Chưa truyền Product ID";
            }
            else
            {
                ViewBag.Message = "Product ID = " + id;
            }

            return View();
        }

        // /Product/Category?name=Laptop
        public IActionResult Category(string? name)
        {
            if (string.IsNullOrEmpty(name))
            {
                ViewBag.Message = "Lỗi: Chưa truyền Category";
            }
            else
            {
                ViewBag.Message = "Category = " + name;
            }

            return View();
        }
    }
}